Powercfg -setacvalueindex scheme_current sub_processor PERFBOOSTMODE 4
Powercfg -setactive scheme_current