Powercfg -setacvalueindex scheme_current sub_processor PERFBOOSTMODE 2
Powercfg -setactive scheme_current